
import java.lang.Math;
import java.util.*;

import java.util.List;
import twitter4j.Status;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;

public class KanyeMusk {
	public static void main(String[] args) throws Exception
	{	
		ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
		configurationBuilder.setDebugEnabled(true)
				.setOAuthConsumerKey("fRdzIsrsBD6VfMdtPRWN7GT4e")
				.setOAuthConsumerSecret("gaKaK34gFqoAzgCy4RRFLY3J1v33g7K0sBqSZAR8pTEkakOLhl")
				.setOAuthAccessToken("1309206811086528512-EFP93gQFX6P3zhjtgc98oAT1dpabeg")
				.setOAuthAccessTokenSecret("tP2o7FughKecG5i3Za0x9oNRkfpA0TwO8TQsvNB3vOTXI");
		TwitterFactory tf = new TwitterFactory(configurationBuilder.build());
		twitter4j.Twitter twitter= tf.getInstance();
		System.out.println("\n\n---------------------\n\n");

		String name1 = "Elon";
		String name2 = "Kanye";
		String tweet;

		int user = randomWithRange(0, 1);
		if(user == 0) {
			tweet = getElon(twitter);
		}
		else {
			tweet = getKanye(twitter);
		}
		//System.out.flush();  
		System.out.println("Tweet: " + tweet);
		System.out.println("Is this " + name1 + "'s tweet or " + name2 + "'s tweet?");
		Scanner scnr = new Scanner(System.in);
		String ans = scnr.nextLine();
		if((ans.equals(name1) && user == 0) || (ans.equals(name2) && user == 1)) {
			System.out.println("Correct!");
		}
		else {
			System.out.println("Wrong!");
		}
		
	}
	
	public static int randomWithRange(int min, int max){
		int range = (max - min) + 1;     
		return (int)(Math.random() * range) + min;
	}
	
	public static String getElon(twitter4j.Twitter twitter) {
		String ans = "";
		try {
		     List<Status> statuses;
		     String user;
		     user = "elonmusk";
		     statuses = twitter.getUserTimeline(user);
		     int num = randomWithRange(0, statuses.size()-1);
		     System.out.println(num);
		     Status status = statuses.get(num);
		     ans = status.getText();
		   } 
		catch (TwitterException te) {
		     te.printStackTrace();
		}
		return ans;
	}
	
	public static String getKanye(twitter4j.Twitter twitter) {
		
		String ans = "";
		try {
		     List<Status> statuses;
		     String user;
		     user = "kanyewest";
		     statuses = twitter.getUserTimeline(user);
		     int num = randomWithRange(0, statuses.size()-1);
			 System.out.println(statuses.size());
		     Status status = statuses.get(num);
		     ans = status.getText();
		   } 
		catch (TwitterException te) {
		     te.printStackTrace();
		}
		return ans;
	}
	
}

/*
try {
     List<Status> statuses;
     String user;
     user = "kanyewest";
     statuses = twitter.getUserTimeline(user);
     System.out.println("Status Count " + statuses.size() + " Feeds");
     for (int i = 0; i < statuses.size(); i++) {
       Status status = statuses.get(i);
       System.out.printf("Tweet Count " + (i + 1) + " ");
       System.out.println(status.getText());
     }
   } catch (TwitterException te) {
     te.printStackTrace();
}
*/
