var Twit = require('twit')

var config = require('./config');
var T = new Twit(config);

//program can only get 20 tweets from each user
var count = 20;

//varaibles to pick random tweet and random user
var randomUser = Math.floor(Math.random() * Math.floor(2));
var users = ['elonmusk', 'kanyewest'];
var randomNum = Math.floor(Math.random() * Math.floor(count));
var tweet = 'https';

var score = 0;

//search query
var params = {
	screen_name: users[randomUser], 
	count: count
};

//get method
T.get('statuses/user_timeline', params, gotData);

function gotData(err, data, response) {
	//this should sort out the tweets with links 
	//(but I can only get the first 20 tweets and for Kanye, which all contains http)
	/*
	while(tweet.includes('https')){
		tweet = data[randomNum].text;
		randomNum = Math.floor(Math.random() * Math.floor(count));
		console.log(randomNum);
	}
	*/
	tweet = data[randomNum].text;
	console.log(tweet);
};

//support readline
const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout
});

//gets user input and check if it's correct
readline.question('Who\'s tweet is this? (\''+ users[0] +'\' or \'' + users[1] +'\')\n\n', name => {
	if(name.localeCompare(users[randomUser]) == 0){
		console.log(`\nCorrect!`);
		score = score + 1
		console.log('Score: ' + score);
	}
	else{
		console.log(`\nWrong!`);
		console.log('Score: ' + score);
	}
  readline.close();
});



