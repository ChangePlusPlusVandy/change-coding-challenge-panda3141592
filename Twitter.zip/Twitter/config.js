module.exports = {
	consumer_key:         'fRdzIsrsBD6VfMdtPRWN7GT4e',
  	consumer_secret:      'gaKaK34gFqoAzgCy4RRFLY3J1v33g7K0sBqSZAR8pTEkakOLhl',
  	access_token:         '1309206811086528512-EFP93gQFX6P3zhjtgc98oAT1dpabeg',
  	access_token_secret:  'tP2o7FughKecG5i3Za0x9oNRkfpA0TwO8TQsvNB3vOTXI'
}